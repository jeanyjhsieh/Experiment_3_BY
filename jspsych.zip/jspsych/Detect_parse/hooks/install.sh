#!/bin/bash

ln -s ../../hooks/pre-commit .git/hooks/pre-commit
